//
//  DVTViewController.h
//  SCXcodeSwitchExpander
//
//  Created by Stefan Ceriu on 16/05/2015.
//  Copyright (c) 2015 Stefan Ceriu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DVTViewController : NSViewController

@end
