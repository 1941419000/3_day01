//
//  IDEIndex.h
//  SCXcodeSwitchExpander
//
//  Created by Stefan Ceriu on 13/03/2014.
//  Copyright (c) 2014 Stefan Ceriu. All rights reserved.
//

@interface IDEIndex : NSObject

- (id)allSymbolsMatchingName:(id)arg1 kind:(id)arg2;

@end

