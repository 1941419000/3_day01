//
//  FastStub.m
//  FastStub
//
//  Created by gao feng on 16/5/25.
//
//

#import "FastStub.h"

@implementation FastStub

@end
