//
//  HHCompletionStrategy.h
//  HHEnumeration-Xcode
//
//  Created by huaxi on 15/10/30.
//  Copyright © 2015年 huaxi. All rights reserved.
//

#import "XcodeMisc.h"
@class DVTTextDocumentLocation;

@interface HHCompletionStrategy : DVTTextCompletionStrategy

@end
