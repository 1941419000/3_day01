//
//  IDEIndexContainerSymbol.h
//  SCXcodeSwitchExpander
//
//  Created by Stefan Ceriu on 17/03/2014.
//  Copyright (c) 2014 Stefan Ceriu. All rights reserved.
//

#import "IDEIndexSymbol.h"

@interface IDEIndexContainerSymbol : IDEIndexSymbol

- (id)children;

@end

