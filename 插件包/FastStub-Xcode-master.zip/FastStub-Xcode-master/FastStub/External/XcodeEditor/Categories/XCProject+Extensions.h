//
//  XCProject+NSDate.h
//  MHImportBuster
//
//  Created by Marko Hlebar on 10/06/2014.
//  Copyright (c) 2014 Marko Hlebar. All rights reserved.
//

#import "XCProject.h"

@interface XCProject (NSDate)
- (NSDate *)dateModified;
@end

@interface XCProject (MHSubprojects)
- (NSArray *)subProjectFiles;
@end