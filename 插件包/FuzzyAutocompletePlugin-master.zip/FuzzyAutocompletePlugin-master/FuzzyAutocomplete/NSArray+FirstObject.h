//
//  NSArray+FirstObject.h
//  FuzzyAutocomplete
//
//  Created by Leszek Ślażyński on 06/05/14.
//
//

#import <Foundation/Foundation.h>

@interface NSArray (FirstObject)

- (id)firstObject NS_AVAILABLE(10_6, 4_0);

@end
