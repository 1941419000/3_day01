//
//  FastStub.h
//  FastStub
//
//  Created by gao feng on 16/5/25.
//
//

#import <Foundation/Foundation.h>

@interface FastStub : NSObject

@end
