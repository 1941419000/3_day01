//
//  NSObject+MHLogMethods.h
//  MHImportBuster
//
//  Created by Marko Hlebar on 08/02/2014.
//  Copyright (c) 2014 Marko Hlebar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (MHLogMethods)
- (void)mhLogMethods;
@end
