//
//  IDEWorkspace+KSImageNamed.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 1/23/13.
//
//

#import "XcodeMisc.h"

@interface IDEWorkspace (KSImageNamed)

@end
