//
//  IDEFileTextSettings.h
//  SCXcodeSwitchExpander
//
//  Created by Stefan Ceriu on 16/05/2015.
//  Copyright (c) 2015 Stefan Ceriu. All rights reserved.
//

@class IDEFileReference;

@interface IDEFileTextSettings : NSObject

@property(retain, nonatomic) IDEFileReference *fileReference;

@end

