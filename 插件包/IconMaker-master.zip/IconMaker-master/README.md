# IconMaker 2.0
an Xcode plug-in for making app icons

Works on Xcode 7.0 - 7.3
###How to use
![how to use](https://raw.githubusercontent.com/kaphacius/IconMaker/master/screencast.gif)

1. Navigate to the icon in asset catalog.
2. Right click and select 'Make An App Icon'
3. Select an image and press 'Okay'

install through [alcatraz](http://alcatraz.io)
or clone, build&run, then relaunch Xcode
