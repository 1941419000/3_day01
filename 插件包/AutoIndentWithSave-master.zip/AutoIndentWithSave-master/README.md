# AutoIndentWithSave
xCode plugin which indent the source code with save<br/>
<p align="center"><h6>(File->Save or Command + S)</h6></p>

<img src="https://github.com/ThilinaHewagama/AutoIndentWithSave/blob/master/auto_indent_screen_shot.jpg">


<br/>
<i>by Thilina Chamin Hewagama</i> <br/>
<a href="http://stackoverflow.com/users/1716859/thilina-chamin-hewagama">
<img src="http://stackoverflow.com/users/flair/1716859.png" width="208" height="58" alt="profile for Thilina Chamin Hewagama at Stack Overflow, Q&amp;A for professional and enthusiast programmers" title="profile for Thilina Chamin Hewagama at Stack Overflow, Q&amp;A for professional and enthusiast programmers">
</a>

<br/>
<h2>How to install</h2>
1) Download the project<br/>
2) Build<br/>
3) Quit xCode & Re-Launch<br/>

<br/>
<i>Note: Tested with xCode 6.4 (supports xCode 6 & above)</i>
<br/>
<br/>
<br/>
