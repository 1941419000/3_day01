//
//  FSInterfaceProcessor.h
//  FastStub
//
//  Created by gao feng on 16/5/20.
//  Copyright © 2016年 music4kid. All rights reserved.
//

#import "FSElementProcessor.h"

@interface FSInterfaceProcessor : FSElementProcessor

@end
