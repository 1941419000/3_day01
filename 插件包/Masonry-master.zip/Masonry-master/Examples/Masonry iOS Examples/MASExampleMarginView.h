//
//  MASExampleMarginView.h
//  Masonry iOS Examples
//
//  Created by Craig Siemens on 2015-02-23.
//  Copyright (c) 2015 Jonas Budelmann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASExampleMarginView : UIView

@end
