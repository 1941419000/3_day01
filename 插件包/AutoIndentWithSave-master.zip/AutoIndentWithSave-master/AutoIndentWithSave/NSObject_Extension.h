//
//  NSObject_Extension.h
//  AutoIndentWithSave
//
//  Created by Thilina Hewagama on 9/7/15.
//  Copyright (c) 2015 Thilina Hewagama. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Xcode_Plugin_Template_Extension)

+ (void)pluginDidLoad:(NSBundle *)plugin;


@end
