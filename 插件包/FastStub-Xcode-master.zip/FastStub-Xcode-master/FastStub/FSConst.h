//
//  FSConst.h
//  FastStub
//
//  Created by gao feng on 16/5/20.
//  Copyright © 2016年 music4kid. All rights reserved.
//

#ifndef FSConst_h
#define FSConst_h

#define Notif               [NSNotificationCenter defaultCenter]

#define Notif_SuggestionStubHide    @"Notif_SuggestionStubHide"

#endif /* FSConst_h */
