//
//  FSSuggestionStubView.m
//  FastStub
//
//  Created by gao feng on 16/5/18.
//  Copyright © 2016年 music4kid. All rights reserved.
//

#import "FSSuggestionStubView.h"

@implementation FSSuggestionStubView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
