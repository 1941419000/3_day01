//
//  HHEnumFormater.h
//  HHEnumerater
//
//  Created by huaxi on 15/10/8.
//  Copyright © 2015年 huaxi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HHEnumFormater : NSString

+ (NSString *)enumFormaterWithString:(NSString *)str;

@end
